#Faça um algoritmo que resolva as seguintes expressões aritméticas considerando A=2,
#B=5 e C=10. Mostre o resultado na tela da expressão
#A: A+B*C/A


a = 2
b = 5
c = 10

soma = a+b*c/a

print("O Resultado da exppressão: A+B*C/A é: ", soma)