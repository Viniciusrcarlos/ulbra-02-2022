#Faça um algoritmo que leia dois números reais e imprima a soma e a média aritmética
#desses números.


numero1 = float(input("Digite o primeirro número: "))
numero2 = float(input("Digite o segundo número: "))

soma = numero1+numero2
media = soma/2

print("A soma dos dois números é: ", soma)
print("A média dos número é: ", media)