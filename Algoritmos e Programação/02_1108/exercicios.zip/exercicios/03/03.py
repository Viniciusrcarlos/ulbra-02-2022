#Faça um algoritmo que leia um número inteiro e imprima seu antecessor e seu
#sucessor.

numero = int(input("Digite um número: "))

ante = numero - 1
suce = numero + 1

print("O sucessor do número é: ", suce)
print("O antecessor do número é", ante)