#Faça um algoritmo para calcular a média aritmética entre três números quaisquer.


numero1 = float(input("Digite um número: "))
numero2 = float(input("Digite outro número: "))
numero3 = float(input("Digite o último número: "))

media = (numero1+numero2+numero3)/3

print("A média dos números é: ", media)