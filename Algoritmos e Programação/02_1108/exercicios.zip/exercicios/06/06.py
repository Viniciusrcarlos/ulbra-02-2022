#FUA para ler dois inteiros (variáveis A e B) e efetuar as operações de adição,
#subtração, multiplicação e divisão de A por B apresentando ao final os quatro resultados
#obtidos.

a = float(input("Digite o primeiro número: "))
b = float(input("Digite o segundo número: "))

adicao = a+b
subtracao = a-b
multi = a*b
div = a/b

print("A soma entre os dois números é: ",adicao)
print("A subtração entre os dois números é: ",subtracao)
print("A multiplicação entre os números é: ",multi)
print("A divisão entre os números é: ",div)

