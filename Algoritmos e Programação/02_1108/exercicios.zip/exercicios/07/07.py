#FUA para calcular a área de um triângulo, exibindo o resultado. A base e a altura são
#dados que devem ser lidos como entrada.
# a = (b * h) / 2

alt = float(input("Digite a altura do triângulo: "))
base = float(input("Digite a altura do triângulo: "))

area = (base*alt)/2

print("A área do triângulo é: ",area)