#F.U.A que leia dois números e calcule qual é o resto da divisão do 1o pelo 2o número.
#Exiba na tela este valor final.

num1 = int(input("Digite o primeiro número: "))
num2 = int(input("Digite o segundo número: "))

div = num1 % num2

print("O resto da divisão é: ",div)