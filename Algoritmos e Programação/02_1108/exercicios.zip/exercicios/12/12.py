#12. F.U.A que leia dois números e calcule qual é o valor inteiro da divisão do 2o pelo 1o
#número. Exiba na tela este valor final.

